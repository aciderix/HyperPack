let currentJobId = null;
let cancelRequested = false;

self.onmessage = async (e) => {
  const msg = e.data;

  if (msg.type === 'cancel') {
    if (currentJobId === msg.id) {
      cancelRequested = true;
    }
    return;
  }

  if (msg.type === 'compress' || msg.type === 'decompress') {
    currentJobId = msg.id;
    cancelRequested = false;
    
    const isCompress = msg.type === 'compress';
    const fileBuffer = msg.fileBuffer;
    const inputSize = fileBuffer.byteLength;
    
    // Simulate blocks (1 block per 32MB, min 1)
    const totalBlocks = Math.max(1, Math.ceil(inputSize / (32 * 1024 * 1024)));
    const strategies = ['BWT', 'LZMA', 'LZ77', 'LZP', 'Delta'];
    
    // Compression factor varies by strategy
    const strategyFactors = {
      'BWT': 0.28 + Math.random() * 0.08,
      'LZMA': 0.22 + Math.random() * 0.06,
      'LZ77': 0.35 + Math.random() * 0.10,
      'LZP': 0.30 + Math.random() * 0.08,
      'Delta': 0.25 + Math.random() * 0.10,
    };
    
    const startTime = Date.now();
    let bytesProcessed = 0;
    let totalCompressedSoFar = 0;
    
    const blocksStats = [];
    
    for (let i = 1; i <= totalBlocks; i++) {
      if (cancelRequested) {
        self.postMessage({ type: 'error', id: msg.id, message: 'Cancelled by user' });
        return;
      }
      
      const blockStrategy = isCompress 
        ? strategies[Math.floor(Math.random() * strategies.length)] 
        : 'Auto';
      
      const blockInputSize = i === totalBlocks 
        ? inputSize - bytesProcessed 
        : Math.floor(inputSize / totalBlocks);
      
      const compressionFactor = isCompress 
        ? (strategyFactors[blockStrategy] || 0.3) 
        : 3.3;
      
      // Simulate processing time per block (500ms - 1500ms)
      const processTime = 500 + Math.random() * 1000;
      const steps = 10;
      const stepTime = processTime / steps;
      
      for (let step = 1; step <= steps; step++) {
        if (cancelRequested) {
          self.postMessage({ type: 'error', id: msg.id, message: 'Cancelled by user' });
          return;
        }
        
        await new Promise(r => setTimeout(r, stepTime));
        
        const stepBytes = Math.floor(blockInputSize / steps);
        bytesProcessed += stepBytes;
        
        // Track compressed bytes for live ratio
        const stepCompressed = Math.floor(stepBytes * compressionFactor);
        totalCompressedSoFar += stepCompressed;
        
        const percent = Math.min(99, Math.floor((bytesProcessed / inputSize) * 100));
        
        // Live ratio calculation
        const currentRatio = isCompress && totalCompressedSoFar > 0
          ? bytesProcessed / totalCompressedSoFar
          : undefined;
        
        self.postMessage({
          type: 'progress',
          id: msg.id,
          percent,
          currentBlock: i,
          totalBlocks,
          strategy: blockStrategy,
          bytesProcessed,
          elapsedMs: Date.now() - startTime,
          currentRatio,
        });
      }
      
      const blockOutputSize = isCompress 
        ? Math.floor(blockInputSize * compressionFactor) 
        : Math.floor(blockInputSize * 3.3);
      
      blocksStats.push({
        strategy: blockStrategy,
        inputSize: blockInputSize,
        outputSize: blockOutputSize,
      });
    }
    
    if (cancelRequested) {
      self.postMessage({ type: 'error', id: msg.id, message: 'Cancelled by user' });
      return;
    }
    
    const totalMs = Date.now() - startTime;
    const outputSize = blocksStats.reduce((acc, b) => acc + b.outputSize, 0);
    const ratio = isCompress ? inputSize / outputSize : outputSize / inputSize;
    
    // Create a dummy output buffer (capped at 10MB for mock)
    const outputBuffer = new ArrayBuffer(Math.min(outputSize, 10 * 1024 * 1024));
    
    let outputFileName = msg.fileName;
    if (isCompress) {
      outputFileName += '.hp';
    } else {
      outputFileName = outputFileName.replace(/\.hp$/, '') || 'decompressed_file';
    }
    
    self.postMessage({
      type: 'complete',
      id: msg.id,
      outputBuffer,
      outputFileName,
      stats: {
        inputSize,
        outputSize,
        ratio,
        totalMs,
        blocks: blocksStats,
      },
    });
  }
};
