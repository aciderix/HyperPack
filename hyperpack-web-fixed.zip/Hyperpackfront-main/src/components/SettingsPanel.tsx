import { X } from 'lucide-react';
import { CompressParams } from '../workers/bridge';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CompressParams;
  onSettingsChange: (settings: CompressParams) => void;
}

export function SettingsPanel({ isOpen, onClose, settings, onSettingsChange }: SettingsPanelProps) {
  if (!isOpen) return null;

  const handleChange = (key: keyof CompressParams, value: any) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-md bg-hp-card h-full shadow-2xl border-l border-hp-border flex flex-col animate-slide-in-right"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-hp-border">
          <h2 className="text-lg font-bold text-hp-text flex items-center gap-2">
            <span>⚙️</span> Compression Settings
          </h2>
          <button 
            onClick={onClose}
            className="p-2 text-hp-muted hover:text-hp-text hover:bg-hp-hover rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-hp-text">Strategy</label>
            <select 
              value={settings.strategy}
              onChange={(e) => handleChange('strategy', e.target.value)}
              className="w-full bg-hp-bg border border-hp-border text-hp-text rounded-lg px-3 py-2 focus:outline-none focus:border-hp-accent"
            >
              <option value="auto">Auto (recommended)</option>
              <option value="bwt">BWT + Range Coder</option>
              <option value="lzma">LZMA</option>
              <option value="lz77">LZ77</option>
              <option value="lzp">LZP + BWT</option>
              <option value="delta">Delta + BWT</option>
              <option value="audio">Audio (PCM)</option>
            </select>
            <p className="text-xs text-hp-muted">Auto lets HyperPack analyze your data and pick the best algorithm automatically.</p>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-hp-text">Block size</label>
            <select 
              value={settings.blockSizeMB}
              onChange={(e) => handleChange('blockSizeMB', Number(e.target.value))}
              className="w-full bg-hp-bg border border-hp-border text-hp-text rounded-lg px-3 py-2 focus:outline-none focus:border-hp-accent"
            >
              <option value={8}>8 MB (~50 MB RAM)</option>
              <option value={32}>32 MB (~200 MB RAM)</option>
              <option value={64}>64 MB (~400 MB RAM)</option>
              <option value={128}>128 MB (~800 MB RAM)</option>
            </select>
            <p className="text-xs text-hp-muted">Larger = better ratio, more RAM.</p>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-hp-text">LZMA Dictionary</label>
            <select 
              value={settings.lzmaDictMB}
              onChange={(e) => handleChange('lzmaDictMB', Number(e.target.value))}
              className="w-full bg-hp-bg border border-hp-border text-hp-text rounded-lg px-3 py-2 focus:outline-none focus:border-hp-accent"
            >
              <option value={16}>16 MB</option>
              <option value={32}>32 MB</option>
              <option value={64}>64 MB</option>
            </select>
            <p className="text-xs text-hp-muted">Larger = better on big binary files.</p>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-hp-text">Compression level</label>
            <select 
              value={settings.level}
              onChange={(e) => handleChange('level', e.target.value)}
              className="w-full bg-hp-bg border border-hp-border text-hp-text rounded-lg px-3 py-2 focus:outline-none focus:border-hp-accent"
            >
              <option value="fast">Fast</option>
              <option value="normal">Normal</option>
              <option value="max">Maximum</option>
            </select>
            <p className="text-xs text-hp-muted">Fast ~2× speed / Normal recommended / Max best ratio</p>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-hp-text">Parallel threads</label>
            <select 
              value={settings.threads}
              onChange={(e) => handleChange('threads', e.target.value === 'auto' ? 'auto' : Number(e.target.value))}
              className="w-full bg-hp-bg border border-hp-border text-hp-text rounded-lg px-3 py-2 focus:outline-none focus:border-hp-accent"
            >
              <option value="auto">Auto (detect cores)</option>
              <option value={1}>1 thread</option>
              <option value={2}>2 threads</option>
              <option value={4}>4 threads</option>
              <option value={8}>8 threads</option>
            </select>
            <p className="text-xs text-hp-muted">Auto detects CPU cores. More = faster on multi-block files.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
